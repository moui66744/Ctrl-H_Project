package Test;

public interface DummyTestInterface {
    int data = 0;
    int a[] = {0, 1, 2, 3};

    public static int reInput(int input) ;

    public static void main(String[] args) ;
}
